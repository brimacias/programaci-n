package ej2oTrim.Herencia.MascotasModificada;


import java.util.*;

public class Inventario {
    public static void main(String[] args) {
        Animales gato = new Gato("Kika", 5, "Vivita y coleando", "01-02-2018", "Negro", false);
        animales.add(gato);
        Animales perro = new Perro("Luna", 4, "Viva", "01-01-2019", "Mezcla de razas", false);
        animales.add(perro);
        Animales canario = new Canario("Bailey", 2, "Vivo", "12-05-2020", "pico", true, "Amarillo", false);
        animales.add(canario);
        Animales loro = new Loro("Iago", 3, "Vivo", "01-03-2020", "pico", true, "India", true);
        animales.add(loro);
        //menu();
        for (Animales animal : animales) {
            animal.muestra();
            System.out.println("");
        }

    }
    private static ArrayList<Animales> animales = new ArrayList<>();

    public void validacionesAlta(Animales a) throws Exception {
        System.out.println("""
                1.- Validación del nombre de la mascota.
                2.- Validación de la edad.
                3.- Comprobación del estado de la mascota.""");
        System.out.println("Introducir el número de la validación: ");
        int numero = leInterfaz.teclado.nextInt();
        switch (numero) {
            case 1:
                if (a.getNombre().matches("[A-Z]{1}[a-z]{1,10}")) {
                    System.out.println("El nombre es válido");
                } else throw new Exception("El nombre de la mascota no es válido.");
            case 2:
                if (a.getEdad() >= 0) {
                    System.out.println("La edad de la mascota es válida.");
                } else throw new Exception("No se puede introducir una edad negativa.");
            case 3:
                if (a.getEstado() != "Se murió T-T") {
                    System.out.println("La mascota está viva.");
                }
        }
    }

    private static String getTipoAnimal(Animales a) {
        if (a instanceof Gato) {
            return "Gato";
        } else if (a instanceof Perro) {
            return "Perro";
        } else if (a instanceof Canario) {
            return "Canario";
        } else if (a instanceof Loro) {
            return "Loro";
        } else {
            return null;
        }
    }

    private String getTipoMascotaClass(Animales m){return m.getClass().getSimpleName();}

    public static void mostrarLista(){
        System.out.println("=== LISTA DE ANIMALES ===");
        for (int i = 0; i < animales.size(); i++) {
            Animales m = animales.get(i);
            String tipo = getTipoAnimal(m);
            String nombre = m.getNombre();
            System.out.println(i + ": " + tipo + " " + nombre);
        }
    }

    //Método que muestra la lista de las revisiones de los perros (clase HistorialRevision)
    public static void mostrarListaRevisionesPerros() {
        System.out.println("Lista de Revisiones del perro: ");
        for (int i = 0; i < animales.size(); i++) {
            Animales m = animales.get(i);
            String tipo = getTipoAnimal(m);
            String nombre = m.getNombre();

            if (Objects.equals(tipo, "Perro")){
                System.out.println(i + ": " + tipo + " " + nombre);
                for (HistorialRevision h : ((Perro)m).getHistorial()) {
                    System.out.println(h.toString());
                }
            }
        }
    }

    public static void mostrarDatosAnimal(int indice){
        if (indice >= 0 && indice < animales.size()) {
            System.out.println("MASCOTA " + indice + ": ");
            Animales a = animales.get(indice);
            a.muestra();
        }
    }

    public static void mostrarDatosTodos(){
        for (int i = 0; i < animales.size(); i++) {
            mostrarDatosAnimal(i);
            System.out.println("");
        }
    }

    public static void insertarAnimal(Animales a){
        animales.add(a);
    }

    public static boolean eliminarAnimal() {
        System.out.println("Introducir indice: ");
        int indice = leInterfaz.teclado.nextInt();
        if (indice >= 0 && indice < animales.size()) {
            animales.remove(indice);
            return true;
        } else {
            return false;
        }
    }

    public static void vaciarInventario(){
        animales.clear();
        System.out.println("El inventario está vacío.");
    }

    //Métodos de ordenación que sí funcionan
    public void ordenacionArrayList(){
        //Ordenado de mayor a menor por edad
        System.out.println("\nArrayList ordenado por nombre de mayor a menor: ");
        Collections.sort(animales, new Comparator<>() {
            @Override
            public int compare(Animales o1, Animales o2) {
                //Aquí se compara m1 con m2 para ordenación ascendente y no al revés
                return o1.getNombre().compareTo((o2.getNombre()));
            }
        });
        printArrayListMascota();
    }

    public void printArrayListMascota() {
        Iterator<Animales> iteradorArrayList = animales.iterator();
        int posicion = 0;
        while (iteradorArrayList.hasNext()) {
            System.out.println("Posición(" + posicion + ") = ");
            iteradorArrayList.next().muestra();
            posicion++;
        }
    }

    /* Ejemplo de búsqueda binaria recursiva con cadenas
     public int busquedaBinariaRecursiva(ArrayList<Mascotas> mascotas,String busqueda, int izquierda, int derecha) {
        //Si izquierda es mayor que derecha significa que no encontramos nada
        if (izquierda > derecha) {
            return -1;
        }
        //Calculamos las mitades
        int indiceDelElementoDelMedio = (int)Math.floor((izquierda + derecha)/2);
        String elementoDelMedio = String.valueOf(indiceDelElementoDelMedio);

        //Primero vamos a comparar y luego vamos a ver si el resultado es negativo, positivo o 0
        int resultadoDeLaComparacion = busqueda.compareTo(elementoDelMedio);

        //Si el resultado de la comparación es 0, significa que ambos elementos son iguales y por lo tanto,
        //hemos encontrado la búsqueda
        if (resultadoDeLaComparacion < 0) {
            return indiceDelElementoDelMedio;
        }

        //Si no, entonces vemos si está a la derecha o a la izquierda
        if (resultadoDeLaComparacion < 0) {
            derecha = indiceDelElementoDelMedio -1;
            return busquedaBinariaRecursiva(mascotas,busqueda,izquierda,derecha);
        } else {
            izquierda = indiceDelElementoDelMedio + 1;
            return busquedaBinariaRecursiva(mascotas,busqueda,izquierda,derecha);
        }
    }*/

    //Búsqueda binaria

    public static int busquedaBinariaConWhile(ArrayList<Animales> animales, String busqueda) {
        Collections.sort(animales, new Comparator<>() {
            @Override
            public int compare(Animales o1, Animales o2) {
                return (o1.getNombre()).compareTo((o2.getNombre()));
            }
        });

        int izquierda = 0;
        int derecha = animales.size() - 1;

        while (izquierda <= derecha) {
            //Calculamos las mitades
            int indiceDelElementoDelMedio = (int)Math.floor((izquierda + derecha)/2);
            String elementoDelMedio = String.valueOf(indiceDelElementoDelMedio);

            //Primero vamos a comparar y ver si el resultado es negativo, positivo o 0
            int resultadoDeLaComparacion = busqueda.compareTo(elementoDelMedio);

            //Si el resultado de la comparación es 0, significa que ambos elementos son iguales y, por lo tanto
            //quiere decir que hemos encontrado la búsqueda
            if (resultadoDeLaComparacion == 0) {
                return indiceDelElementoDelMedio;
            }

            //Si no, entonces vemos si está a la izquierda o derecha
            if (resultadoDeLaComparacion < 0) {
                derecha = indiceDelElementoDelMedio -1;
            } else {
                izquierda = indiceDelElementoDelMedio + 1;
            }
        }
        //Si no se rompió el ciclo ni regresó el índice, entonces el elemento no existe
        return -1;

        /*Implementación:
        ArrayList<Mascotas> mascota;
        String busqueda = "Kika";

        int indiceDelElementoBuscado = busquedaBinariaConWhile(mascotas, busqueda);
        sout("Con el ciclo While - El elemento buscado (" + busqueda + ") se encuentra en el indice " +
        indiceDelElementoBuscado);
         */
    }

    public static int busquedaLineal(ArrayList<Animales> animales, String busqueda) {
        int resultado = 0;
        for (Animales animal : animales) {
            if (animal.getNombre() == busqueda) {
                resultado = 1;
            } else {
                resultado = -1;
            }
        }
         /*int indice = mascotas.indexOf(busqueda);
         if (indice != -1) {
             System.out.println("La búsqueda '" + busqueda + "' está en el índice " + indice);
         } else {
             System.out.println("El elemento no existe. ");
         }*/
        return resultado;
    }

    public static void menu(ArrayList<Animales> animales, Animales a) {
        int num = 0;
        do {
            menuPrincipal();
            int indice = 0;

            System.out.println("\nIntroducir número de la operación deseada: ");
            num = leInterfaz.teclado.nextInt();
            switch (num) {
                case 1:
                    mostrarLista();
                    break;
                case 2:
                    mostrarDatosAnimal(indice);
                    break;
                case 3:
                    mostrarDatosTodos();
                    break;
                case 4:
                    insertarAnimal(a);
                    break;
                case 5:
                    eliminarAnimal();
                    break;
                case 6:
                    vaciarInventario();
                    break;
            }
        } while (num <= 6) ;
    }
    public static void menuPrincipal() {
        System.out.println();
        System.out.println("""
                -----MASCOTAS-----
                1.-Mostrar lista de los animales (tipo y nombre).
                2.-Mostrar todos los datos de un animal en concreto.
                3.-Mostrar todos los datos de todos los animales.
                4.-Insertar un animal al inventario.
                5.-Eliminar un animal del inventario.
                6.-Vaciar el inventario.""");
    }
}
