package ej2oTrim.Herencia.MascotasModificada;

import java.util.Scanner;

public interface leInterfaz {
    Scanner teclado = new Scanner(System.in);
}
